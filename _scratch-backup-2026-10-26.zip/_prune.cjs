// _prune.cjs —— 删掉不适合孩子的、以及英语本身有问题的句子
const fs = require('fs');
const DATA = 'public/data/EnglishShorts/data.json';

// 逐句写明理由，方便以后复查
const REMOVE = {
  'your fly is down.': '涉及隐私，孩子不该这么说',
  "it's killing me.": '语义含糊，可指「笑死了」也可指「疼死了」，容易用错场合',
  'that sucks.': '轻度粗话',
  'over my dead body.': '夸张且带「死」字，不适合孩子',
  "i don't wonder.": '非标准用法，现代英语几乎不说',
  'no cap.': '太新的俚语（cap=谎言），孩子学了容易误解',
  'get lost.': '骂人',
  'shut up.': '骂人',
  'bite me.': '骂人',
  'screw you.': '粗俗',
  "i'm screwed.": '粗俗',
  'big mouth.': '说人缺点（叫人大嘴巴）',
};

// 下面这些扫到了但判断为「可用」，保留：
//   Come closer.        —— 只是 closer 里含 lose 才被正则误命中
//   Whatever you say.   —— 只是 Whatever 里含 hate 才被正则误命中
//   Shame on you.       —— 大人对孩子说的常见责备，不是脏话
//   You asked for it.   —— 常见习语，不算粗俗
//   Back off. / Hands off. / Bite your tongue. —— 表达边界，正常英语

const norm = s => String(s).toLowerCase().replace(/\s+/g, ' ').trim();

const data = JSON.parse(fs.readFileSync(DATA, 'utf8'));
const before = data.groups.reduce((s, g) => s + g.items.length, 0);
const removed = [];
const missed = [];

data.groups.forEach(g => {
  g.items = g.items.filter(it => {
    const k = norm(it.en);
    if (Object.prototype.hasOwnProperty.call(REMOVE, k)) {
      removed.push(g.icon + g.name + ' | ' + it.en + ' → ' + it.name + '   【' + REMOVE[k] + '】');
      return false;
    }
    return true;
  });
});

Object.keys(REMOVE).forEach(k => {
  if (!removed.some(r => norm(r.split('→')[0].split('|')[1]) === k)) missed.push(k);
});

// 清掉被删空的组
const empty = data.groups.filter(g => g.items.length === 0).map(g => g.icon + g.name);
data.groups = data.groups.filter(g => g.items.length > 0);

fs.writeFileSync(DATA, JSON.stringify(data, null, 2), 'utf8');

const after = data.groups.reduce((s, g) => s + g.items.length, 0);
console.log('删除 ' + removed.length + ' 句：');
removed.forEach(r => console.log('  ✗ ' + r));
console.log('');
console.log('没找到（可能已不在书里）：' + (missed.length ? missed.join(' / ') : '无'));
console.log('删空的组：' + (empty.length ? empty.join(' / ') : '无'));
console.log('');
console.log(before + ' 句 → ' + after + ' 句 | ' + data.groups.length + ' 组');
