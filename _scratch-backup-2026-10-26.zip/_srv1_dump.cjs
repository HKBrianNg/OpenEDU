/**
 * 看看 srv1 里到底是什么粒度。
 *   node _srv1_dump.cjs <xxx.srv1> [显示条数]
 */
const fs = require('fs');

const src = process.argv[2];
const limit = Number(process.argv[3] || 40);

const raw = fs.readFileSync(src, 'utf8');

const nodes = raw.match(/<text\b[^>]*>[\s\S]*?<\/text>/g) || [];
console.log('text 节点数: ' + nodes.length);
console.log('');

const attrs = n => {
  const get = k => {
    const m = n.match(new RegExp(k + '="([^"]*)"'));
    return m ? m[1] : '';
  };
  return { start: parseFloat(get('start')), dur: parseFloat(get('dur')) };
};

const items = nodes.map(n => {
  const a = attrs(n);
  const text = decodeEntities(
    n.replace(/^<text\b[^>]*>/, '').replace(/<\/text>$/, '').replace(/<[^>]*>/g, '')
  ).replace(/\s+/g, ' ').trim();
  return { ...a, text };
});

console.log('=== 前 ' + limit + ' 条 ===');
items.slice(0, limit).forEach((it, i) => {
  console.log(
    String(i).padStart(3) + ' [t=' + it.start.toFixed(1).padStart(7) +
    ' d=' + (isNaN(it.dur) ? '  ?  ' : it.dur.toFixed(2)) + '] ' +
    JSON.stringify(it.text)
  );
});

// 时长分布，用来判断是不是滚动窗口
const buckets = { '<0.5s': 0, '0.5-2s': 0, '2-5s': 0, '>5s': 0 };
items.forEach(it => {
  if (isNaN(it.dur)) return;
  if (it.dur < 0.5) buckets['<0.5s']++;
  else if (it.dur < 2) buckets['0.5-2s']++;
  else if (it.dur < 5) buckets['2-5s']++;
  else buckets['>5s']++;
});
console.log('');
console.log('时长分布: ' + JSON.stringify(buckets));

const words = items.map(it => it.text.split(/\s+/).filter(Boolean).length);
console.log('每节点词数 min/中位/max: ' + Math.min(...words) + ' / ' +
  words.slice().sort((a, b) => a - b)[Math.floor(words.length / 2)] + ' / ' + Math.max(...words));

function decodeEntities(s) {
  return s
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ');
}
