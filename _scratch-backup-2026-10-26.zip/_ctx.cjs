// _ctx.cjs —— 查可疑短语在原始字幕里的上下文，并算出哪些是书里还没有的新句
const fs = require('fs');

const raw = fs.readFileSync('_f4_srv1.en-orig.srv1', 'utf8');
const txt = raw.replace(/<[^>]*>/g, ' ').replace(/&amp;#39;/g, "'").replace(/\s+/g, ' ');

['follow me', 'kind of', "what's next", 'okie', 'join cia', 'zip it'].forEach(k => {
  const i = txt.toLowerCase().indexOf(k);
  console.log('--- ' + k + ' ---');
  console.log(i >= 0 ? txt.slice(Math.max(0, i - 170), i + 210) : '(原始字幕里没有)');
  console.log('');
});

// ── 与现有数据去重 ──
const RE = [
  [/you're/gi, 'you are'], [/i'm/gi, 'i am'], [/it's/gi, 'it is'],
  [/that's/gi, 'that is'], [/don't/gi, 'do not'], [/can't/gi, 'cannot'],
  [/didn't/gi, 'did not'], [/doesn't/gi, 'does not'], [/isn't/gi, 'is not'],
  [/i'll/gi, 'i will'], [/i'd/gi, 'i would'], [/i've/gi, 'i have'],
  [/we're/gi, 'we are'], [/let's/gi, 'let us'], [/how's/gi, 'how is'],
  [/what's/gi, 'what is'], [/who's/gi, 'who is'], [/got to/gi, 'got to'],
];
const norm = s => {
  let t = String(s);
  RE.forEach(([re, to]) => { t = t.replace(re, to); });
  return t.toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, ' ').trim();
};

const data = JSON.parse(fs.readFileSync('public/data/EnglishShorts/data.json', 'utf8'));
const have = new Map();
data.groups.forEach(g => g.items.forEach(it => have.set(norm(it.en), g.name)));

const lines = fs.readFileSync('_sentences_v4.txt', 'utf8')
  .split('\n').map(s => s.trim()).filter(Boolean)
  .filter(l => l.replace(/[.!?]/g, '').trim().split(/\s+/).length >= 2);

const dup = [], fresh = [];
lines.forEach(l => {
  if (have.has(norm(l))) dup.push(l + '   = 已有「' + have.get(norm(l)) + '」');
  else fresh.push(l);
});

console.log('=== 干净句 ' + lines.length + ' → 重复 ' + dup.length + ' | 真正新增 ' + fresh.length + ' ===');
console.log('');
console.log('=== 重复(跳过) ===');
dup.forEach(d => console.log('  ' + d));
console.log('');
console.log('=== 新增 ' + fresh.length + ' 句 ===');
fresh.forEach((l, i) => console.log(String(i + 1).padStart(3) + '. ' + l));
fs.writeFileSync('_fresh_v4.txt', fresh.join('\n') + '\n', 'utf8');
