// _add_shorts.cjs
// 把新视频提取出来的短句合并进 public/data/EnglishShorts/data.json。
//
// 为什么不手改 JSON：那文件里已经有 97 句，手写容易改坏，而且新视频里
// 有 10 句是重复的（Have a seat. / Hold on. / Take it easy. ...），得按英文去重。
// 脚本只做两件事：往已有组里追加、在末尾新增组。已有条目一律不动。

const fs = require('fs');
const path = require('path');

const DATA = path.join(__dirname, 'public/data/EnglishShorts/data.json');

/** 去重用的归一化：小写、去标点、压空格 */
const norm = s => String(s).toLowerCase().replace(/[^a-z0-9'\s]/g, '').replace(/\s+/g, ' ').trim();

// ── 新增的组 ──────────────────────────────────────────────
const newGroups = [
  {
    id: 'visiting',
    name: '做客与寒暄',
    en: 'Visiting',
    icon: '🏠',
    items: [
      { en: 'Come over.', name: '过来玩吧。' },
      { en: 'After you.', name: '您先请。' },
      { en: 'Allow me.', name: '让我来吧。' },
      { en: 'Come on in.', name: '进来吧。' },
      { en: 'It\'s on me.', name: '我请客。' },
      { en: 'I appreciate it.', name: '太感谢了。' },
      { en: 'Not at all.', name: '别客气。' },
    ],
  },
  {
    id: 'reactions',
    name: '随口评价',
    en: 'Quick Reactions',
    icon: '👍',
    items: [
      { en: 'Nice try.', name: '想得美。' },
      { en: 'Way to go.', name: '干得好！' },
      { en: 'Good job.', name: '做得好。' },
      { en: 'Not bad.', name: '还不错。' },
      { en: 'Could be.', name: '有可能。' },
      { en: 'That\'s right.', name: '没错。' },
      { en: 'That\'s true.', name: '确实如此。' },
      { en: 'That\'s impossible.', name: '这不可能。' },
      { en: 'Absolutely not.', name: '绝对不行。' },
      { en: 'Neither do I.', name: '我也不。' },
      { en: 'Sort of.', name: '算是吧。' },
      { en: 'Not really.', name: '不太算。' },
      { en: 'Not exactly.', name: '不完全是。' },
      { en: 'Who cares.', name: '谁在乎呢。' },
      { en: 'Why not.', name: '为什么不呢。' },
      { en: 'Same here.', name: '我也是。' },
      { en: 'My mistake.', name: '我的错。' },
    ],
  },
  {
    id: 'cominggoing',
    name: '出门与到达',
    en: 'Coming & Going',
    icon: '🚶',
    items: [
      { en: 'Time to go.', name: '该走了。' },
      { en: 'Ready to go.', name: '准备好了，可以走了。' },
      { en: 'I\'m home.', name: '我回来了。' },
      { en: 'Come along.', name: '一起来吧。' },
      { en: 'Move over.', name: '挪过去一点。' },
      { en: 'Get down.', name: '下来。' },
      { en: 'Hold on tight.', name: '抓紧了。' },
      { en: 'Have fun.', name: '玩得开心。' },
      { en: 'Take care.', name: '保重。' },
      { en: 'Sleep tight.', name: '睡个好觉。' },
    ],
  },
  {
    id: 'mood',
    name: '情绪与劝阻',
    en: 'Calm Down',
    icon: '😤',
    items: [
      { en: 'Calm down.', name: '冷静点。' },
      { en: 'Stop it.', name: '别闹了。' },
      { en: 'Stop being rude.', name: '别这么没礼貌。' },
      { en: 'Hold your tongue.', name: '别多嘴。' },
      { en: 'Give me a break.', name: '饶了我吧。' },
      { en: 'Leave me alone.', name: '别烦我。' },
      { en: 'Don\'t bug me.', name: '别缠着我。' },
      { en: 'Watch out.', name: '小心！' },
    ],
  },
  {
    id: 'decide',
    name: '拿不定主意',
    en: 'Making Up Your Mind',
    icon: '🤔',
    items: [
      { en: 'Think it over.', name: '好好想想。' },
      { en: 'Think twice.', name: '三思而行。' },
      { en: 'It takes time.', name: '这事急不得。' },
      { en: 'Time will tell.', name: '时间会给出答案。' },
      { en: 'It\'s up to you.', name: '你来决定。' },
      { en: 'Let me see.', name: '让我想想。' },
      { en: 'I\'d rather not.', name: '我还是算了。' },
      { en: 'Let it be.', name: '随它去吧。' },
      { en: 'Any day will do.', name: '哪天都行。' },
      { en: 'It\'s about time.', name: '早该这样了。' },
      { en: 'Come to the point.', name: '说重点吧。' },
      { en: 'Say again?', name: '再说一遍？' },
      { en: 'Since when?', name: '从什么时候开始的？' },
      { en: 'Where to?', name: '去哪儿？' },
      { en: 'What for?', name: '为了什么？' },
    ],
  },
];

// ── 往已有组里追加 ────────────────────────────────────────
const extend = {
  phone: [
    { en: 'Give me a call.', name: '给我打个电话。' },
    { en: 'I can\'t get through.', name: '我打不通。' },
    { en: 'Who\'s calling?', name: '谁打来的？' },
  ],
  cheerup: [
    { en: 'Trust me.', name: '相信我。' },
    { en: 'Keep going.', name: '继续加油。' },
    { en: 'I made it.', name: '我做到了。' },
  ],
  smalltalk: [
    { en: 'What\'s up?', name: '怎么了？' },
    { en: 'Not much.', name: '没什么。' },
    { en: 'Can\'t complain.', name: '还行吧。' },
    { en: 'Guess what.', name: '你猜怎么着。' },
    { en: 'How come?', name: '怎么会呢？' },
    { en: 'What else?', name: '还有呢？' },
    { en: 'Like what?', name: '比如说？' },
    { en: 'Just checking.', name: '随便问问。' },
    { en: 'Anything new?', name: '有什么新鲜事吗？' },
    { en: 'Sounds good.', name: '听起来不错。' },
    { en: 'You\'re kidding.', name: '你在开玩笑吧。' },
  ],
  fit: [
    { en: 'It doesn\'t fit.', name: '不合身。' },
    { en: 'It\'s too tight.', name: '太紧了。' },
  ],
  checkingin: [
    { en: 'Feel better.', name: '祝你早日康复。' },
    { en: 'You look tired.', name: '你看起来有点累。' },
  ],
  handy: [
    { en: 'Got it.', name: '明白了。' },
    { en: 'No problem.', name: '没问题。' },
    { en: 'Here I am.', name: '我来了。' },
    { en: 'Not yet.', name: '还没有。' },
    { en: 'That\'s it.', name: '就是这样。' },
    { en: 'I\'ll take this.', name: '我要这个。' },
    { en: 'Listen up.', name: '听好了。' },
    { en: 'Is that clear?', name: '明白了吗？' },
    { en: 'We are all ears.', name: '我们洗耳恭听。' },
    { en: 'I swear.', name: '我发誓。' },
    { en: 'Touch wood.', name: '敲敲木头，但愿走好运。' },
  ],
};

// ── 执行 ──────────────────────────────────────────────────
const data = JSON.parse(fs.readFileSync(DATA, 'utf8'));
const before = data.groups.reduce((s, g) => s + g.items.length, 0);

// 先建索引：已有的英文句子，一个都不许重复出现
const seen = new Set();
data.groups.forEach(g => g.items.forEach(it => seen.add(norm(it.en))));

let added = 0;
let skipped = 0;
const skippedList = [];

/** 往指定组追加，重复的跳过 */
function push(group, items) {
  items.forEach(it => {
    if (seen.has(norm(it.en))) {
      skipped++;
      skippedList.push(it.en);
      return;
    }
    seen.add(norm(it.en));
    group.items.push(it);
    added++;
  });
}

// 1) 追加到已有组
Object.entries(extend).forEach(([gid, items]) => {
  const g = data.groups.find(x => x.id === gid);
  if (!g) throw new Error('找不到要追加的分组：' + gid);
  push(g, items);
});

// 2) 新增组（整组去重后加在末尾）
const existIds = new Set(data.groups.map(g => g.id));
newGroups.forEach(ng => {
  if (existIds.has(ng.id)) throw new Error('分组 id 已存在：' + ng.id);
  const g = { ...ng, items: [] };
  push(g, ng.items);
  data.groups.push(g);
});

fs.writeFileSync(DATA, JSON.stringify(data, null, 2), 'utf8');

const after = data.groups.reduce((s, g) => s + g.items.length, 0);
console.log('原有 ' + before + ' 句 → 现在 ' + after + ' 句');
console.log('新增 ' + added + ' 句 | 跳过重复 ' + skipped + ' 句');
if (skippedList.length) console.log('  跳过：' + skippedList.join(' / '));
console.log('分组 ' + data.groups.length + ' 组');
