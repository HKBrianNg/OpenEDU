// 临时：导出指定区间的字幕文本（优先官方字幕）
const fs = require('fs');
const map = JSON.parse(fs.readFileSync('_official_map.json', 'utf8'));
const d = JSON.parse(fs.readFileSync('public/data/EnglishVideo/Kingdergarten/Kingdergarten.json', 'utf8'));
const from = Number(process.argv[2]), to = Number(process.argv[3]);
const RE = /[?&]v=([A-Za-z0-9_-]{11})/;

for (const it of (d.items || []).filter((i) => i.id >= from && i.id <= to)) {
  const o = map[String(it.id)];
  const m = it.url.match(RE);
  const v = o || (m ? m[1] : null);
  const p = (o ? '_subs2/' : '_subs/') + v + '.en.json3';
  if (!fs.existsSync(p)) { console.log(`#${it.id} 缺字幕`); continue; }
  const j = JSON.parse(fs.readFileSync(p, 'utf8'));
  console.log(`########## #${it.id} ${it.englishName} (${o ? '官方字幕' : '自动字幕'}) ##########`);
  for (const e of j.events) {
    let t = (e.segs || []).map((s) => s.utf8 || '').join('')
      .replace(/\[[A-Za-z ]+\]/g, '').replace(/\([A-Z][A-Z ]+\)/g, '')
      .replace(/♪/g, '').replace(/\s+/g, ' ').trim();
    if (!t || t.length < 2) continue;
    const mm = String(Math.floor(e.tStartMs / 60000)).padStart(2, '0');
    const ss = String(Math.floor((e.tStartMs % 60000) / 1000)).padStart(2, '0');
    console.log(`[${mm}:${ss}] ${t}`);
  }
}
