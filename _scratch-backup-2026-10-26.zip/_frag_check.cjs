// _frag_check.cjs —— 看看第四个视频还有哪些短语没被捞出来
const fs = require('fs');

const lines = fs.readFileSync('_sentences_v4.txt', 'utf8')
  .split('\n').map(s => s.trim()).filter(Boolean);
const clean = lines.filter(l => l.replace(/[.!?]/g, '').trim().split(/\s+/).length >= 2);
const frag = lines.filter(l => l.replace(/[.!?]/g, '').trim().split(/\s+/).length === 1);

console.log('第四集成品：干净 ' + clean.length + ' 句 | 单词碎片 ' + frag.length + ' 行');
console.log('');
console.log('=== 那 ' + frag.length + ' 个碎片 ===');
console.log(frag.join(' '));
console.log('');

// 这些碎片是三遍识别不一致导致折叠失败的残骸。
// 回到原始字幕，按「连续三遍、允许个别词不同」再找一遍。
const raw = fs.readFileSync('_f4_srv1.en-orig.srv1', 'utf8');
const nodes = [...raw.matchAll(/<text[^>]*>([\s\S]*?)<\/text>/g)]
  .map(m => m[1].replace(/<[^>]*>/g, '').replace(/&amp;#39;/g, "'")
    .replace(/&#39;/g, "'").replace(/\s+/g, ' ').trim())
  .filter(Boolean);

console.log('原始节点 ' + nodes.length + ' 个');

// 把节点流拼成词序列（跟 _rebuild.cjs 一样的思路）
const stream = nodes.join(' ').split(/\s+/).filter(Boolean);
console.log('拼接词数 ' + stream.length);

// 模糊三连：三遍里允许最多 1 个词不同
const sim = (a, b) => {
  if (a.length !== b.length) return 0;
  let d = 0;
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) d++;
  return d;
};

const found = [];
for (let len = 2; len <= 6; len++) {
  for (let i = 0; i + len * 3 <= stream.length; i++) {
    const a = stream.slice(i, i + len);
    const b = stream.slice(i + len, i + 2 * len);
    const c = stream.slice(i + 2 * len, i + 3 * len);
    if (sim(a, b) > 1 || sim(a, c) > 1) continue;
    // 三遍里取「多数票」还原最可能的写法
    const words = a.map((w, k) => {
      const votes = {};
      [a[k], b[k], c[k]].forEach(v => { votes[v] = (votes[v] || 0) + 1; });
      return Object.entries(votes).sort((x, y) => y[1] - x[1])[0][0];
    });
    found.push({ i, len, text: words.join(' ') });
  }
}

// 只保留起点不重叠的（贪心，从长到短）
found.sort((x, y) => x.i - y.i || y.len - x.len);
const picked = [];
let lastEnd = -1;
found.forEach(f => {
  if (f.i < lastEnd) return;
  picked.push(f.text);
  lastEnd = f.i + f.len * 3;
});

const RE = [[/you're/gi, 'you are'], [/i'm/gi, 'i am'], [/it's/gi, 'it is'],
  [/that's/gi, 'that is'], [/don't/gi, 'do not'], [/can't/gi, 'cannot'],
  [/i'll/gi, 'i will'], [/let's/gi, 'let us'], [/how's/gi, 'how is'],
  [/what's/gi, 'what is'], [/who's/gi, 'who is']];
const norm = s => {
  let t = String(s);
  RE.forEach(([re, to]) => { t = t.replace(re, to); });
  return t.toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, ' ').trim();
};

const data = JSON.parse(fs.readFileSync('public/data/EnglishShorts/data.json', 'utf8'));
const have = new Set();
data.groups.forEach(g => g.items.forEach(it => have.add(norm(it.en))));

const fresh = [...new Set(picked)].filter(p => !have.has(norm(p)));
console.log('');
console.log('=== 模糊匹配新捞到的、书里还没有的 ' + fresh.length + ' 句 ===');
fresh.forEach((p, i) => console.log(String(i + 1).padStart(3) + '. ' + p));
