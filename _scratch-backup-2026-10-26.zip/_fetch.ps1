# _fetch.ps1 —— 抓一个视频的英文字幕并复原成句子清单
#
# 用法（在 client 目录下）：
#   .\ _fetch.ps1 -Url "https://www.youtube.com/watch?v=xxxx" -Tag f5
#   .\ _fetch.ps1 -Url "https://www.youtube.com/watch?v=xxxx" -Tag f5 -Cookies cookies.txt
#
# Tag 只是给文件编号用的，比如 f5 / f6，产物是 _f5_srv1.en-orig.srv1 和 _sentences_f5.txt
# 被 YouTube 限流时带上 -Cookies cookies.txt（先用浏览器扩展导出）

param(
    [Parameter(Mandatory = $true)][string]$Url,
    [Parameter(Mandatory = $true)][string]$Tag,
    [string]$Cookies = ''
)

$ErrorActionPreference = 'Stop'
$y = 'C:\Users\brian\AppData\Roaming\Python\Python314\Scripts\yt-dlp.exe'

$yargs = @(
    '--no-warnings',
    '--skip-download',
    '--write-auto-subs',
    '--sub-langs', 'en-orig',
    '--sub-format', 'srv1',
    '-o', "_${Tag}_srv1.%(ext)s",
    '--no-playlist'
)
if ($Cookies) { $yargs += @('--cookies', $Cookies) }
$yargs += $Url

Write-Output '=== 下载字幕 ==='
$p = Start-Process -FilePath $y -ArgumentList $yargs -NoNewWindow -Wait -PassThru
if ($p.ExitCode -ne 0) {
    Write-Output "下载失败，退出码 $($p.ExitCode)"
    Write-Output '如果是 Sign in to confirm you are not a bot，说明还在限流，过几天再试，或加 -Cookies'
    exit 1
}

$srv = "_${Tag}_srv1.en-orig.srv1"
if (-not (Test-Path $srv)) {
    Write-Output "没找到字幕文件：$srv"
    exit 1
}
$kb = [math]::Round((Get-Item $srv).Length / 1KB, 1)
Write-Output "字幕已存：$srv （$kb KB）"
Write-Output ''

Write-Output '=== 复原句子 ==='
node '_rebuild.cjs' $srv "_sentences_${Tag}.txt"

Write-Output ''
Write-Output "下一步：node _ctx.cjs 查可疑句并算出新增（记得先改 _ctx.cjs 里的文件名）"
