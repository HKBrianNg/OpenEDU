// 合并基础词表 + 人工释义，生成正式生字表 vocabulary.json
// 释义分批写在 _gloss-*.json 里，这里只做合并，方便分批补
const fs = require('fs');
const path = require('path');

const base = JSON.parse(fs.readFileSync('_vocab-base.json', 'utf8'));

// 汇总所有 _gloss-*.json
const gloss = {};
for (const f of fs.readdirSync('.').filter((x) => /^_gloss-\d+\.json$/.test(x))) {
  Object.assign(gloss, JSON.parse(fs.readFileSync(f, 'utf8')));
}

const words = base.map((x) => ({
  w: x.w,
  zh: gloss[x.w] || '',
  freq: x.freq,
  ex: x.ex,
  exZh: x.exZh,
  epId: x.epId,
  epName: x.epName,
  epZh: x.epZh,
  eps: x.eps,
}));

const glossed = words.filter((x) => x.zh).length;
const out = {
  meta: {
    total: words.length,
    glossed,
    episodes: 52,
    updatedAt: new Date().toISOString().slice(0, 10),
  },
  words,
};

const dest = 'public/data/EnglishVideo/Kingdergarten/vocabulary.json';
fs.writeFileSync(dest, JSON.stringify(out), 'utf8');

console.log(`词条 ${words.length} | 已释义 ${glossed} (${Math.round((glossed / words.length) * 100)}%) | 待补 ${words.length - glossed}`);
console.log(`文件 ${dest} (${Math.round(fs.statSync(dest).size / 1024)}KB)`);

// 顺带报一下：有没有释义文件里的词不在词表里（写错了词）
const inBase = new Set(base.map((x) => x.w));
const orphan = Object.keys(gloss).filter((k) => !inBase.has(k));
if (orphan.length) console.log('警告 释义文件里有不属于词表的词: ' + orphan.join(','));
