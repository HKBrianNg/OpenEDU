// _add_shorts4.cjs —— 第四个视频的短句合并进 EnglishShorts/data.json
// 沿用 _add_shorts3.cjs 的缩写展开去重。
// 手动跳过 3 句含义不明的：Your toast. / Gag me. / You finished.

const fs = require('fs');
const path = require('path');
const DATA = path.join(__dirname, 'public/data/EnglishShorts/data.json');

const RE = [
  [/you're/gi, 'you are'], [/i'm/gi, 'i am'], [/it's/gi, 'it is'],
  [/that's/gi, 'that is'], [/don't/gi, 'do not'], [/can't/gi, 'cannot'],
  [/didn't/gi, 'did not'], [/doesn't/gi, 'does not'], [/isn't/gi, 'is not'],
  [/i'll/gi, 'i will'], [/i'd/gi, 'i would'], [/i've/gi, 'i have'],
  [/we're/gi, 'we are'], [/let's/gi, 'let us'], [/how's/gi, 'how is'],
  [/what's/gi, 'what is'], [/who's/gi, 'who is'],
];
const norm = s => {
  let t = String(s);
  RE.forEach(([re, to]) => { t = t.replace(re, to); });
  return t.toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, ' ').trim();
};

const newGroups = [
  { id: 'routine', name: '起居作息', en: 'Daily Routine', icon: '🌙', items: [
    ['Get dressed.', '穿好衣服。'],
    ['Wake up.', '起床了。'],
    ['Get up.', '起来吧。'],
    ['Stand up.', '站起来。'],
    ['Go upstairs.', '上楼去。'],
    ['Go downstairs.', '下楼去。'],
    ['Still up?', '还没睡吗？'],
    ['Sweet dreams.', '做个好梦。'],
  ]},
  { id: 'road', name: '路上与交通', en: 'On the Road', icon: '🚗', items: [
    ['Pull over.', '靠边停车。'],
    ['Go straight.', '一直往前走。'],
    ['Move aside.', '让一下。'],
    ['Drive safe.', '开车小心。'],
    ['Slow down.', '慢一点。'],
    ['Over there.', '在那边。'],
    ['This way.', '往这边走。'],
  ]},
  { id: 'goodbye', name: '道别', en: 'Saying Goodbye', icon: '👋', items: [
    ['Got to go.', '我得走了。'],
    ['See you.', '再见。'],
    ['So long.', '再见啦。'],
    ['Come back.', '回来吧。'],
  ]},
  { id: 'treating', name: '请客与致歉', en: 'Treating & Sorry', icon: '🙏', items: [
    ['My treat.', '我请客。'],
    ['How much?', '多少钱？'],
    ['Money talks.', '有钱好办事。'],
    ['Pardon me.', '对不起，请再说一遍。'],
    ['I apologize.', '我道歉。'],
    ['Forgive me.', '请原谅我。'],
    ['I promise.', '我保证。'],
    ['Promise me.', '答应我。'],
  ]},
  { id: 'states', name: '状况与感受', en: 'How Things Stand', icon: '😖', items: [
    ["I'm beat.", '我累坏了。'],
    ["I'm done.", '我不干了。'],
    ["I'm confused.", '我被弄糊涂了。'],
    ["I'm screwed.", '我完蛋了。'],
    ['That hurts.', '好痛。'],
    ["It's over.", '都结束了。'],
    ['It works.', '管用了。'],
    ['No way.', '不会吧。'],
    ['Not again.', '又来了。'],
    ['No comment.', '无可奉告。'],
    ['Holy cow.', '天哪。'],
    ['What now?', '又怎么了？'],
    ["Everything's fine.", '一切都好。'],
  ]},
];

const extend = {
  handy: [
    ['Hi there.', '你好呀。'],
    ['Welcome back.', '欢迎回来。'],
    ['All set.', '都准备好了。'],
    ['All right.', '好的。'],
    ['All done.', '做完了。'],
    ['Sure thing.', '没问题，当然。'],
    ['Of course.', '当然。'],
    ['I see.', '我明白了。'],
    ['Me too.', '我也是。'],
    ['My pleasure.', '我的荣幸。'],
    ['Come on.', '快点吧。'],
    ['Never mind.', '算了，没关系。'],
    ['Forget it.', '算了，别提了。'],
    ['Anything else?', '还有别的吗？'],
    ['Nothing else.', '没别的了。'],
    ["That's all.", '就这些。'],
    ['Any problem?', '有什么问题吗？'],
    ["Who's next?", '下一个是谁？'],
    ['Your turn.', '轮到你了。'],
    ['Save it.', '省省吧，别说了。'],
    ['Hold it.', '等一下。'],
    ['Show me.', '给我看看。'],
    ['Try this.', '试试这个。'],
    ['Get it?', '明白了吗？'],
    ['Say cheese.', '笑一个。'],
    ['Sing along.', '一起唱。'],
    ['Come in.', '请进。'],
  ],
  smalltalk: [
    ["How's everything?", '一切都好吗？'],
    ['Nothing much.', '没什么。'],
    ["What's new?", '有什么新鲜事吗？'],
    ['How so?', '怎么会这样？'],
    ['Pretty much.', '差不多吧。'],
    ['Who knows.', '谁知道呢。'],
    ['I guess.', '我想是吧。'],
    ['Beats me.', '我可不知道。'],
    ['No kidding.', '不开玩笑，真的。'],
    ['Just kidding.', '开玩笑的。'],
    ['You know.', '你知道的。'],
    ['You wish.', '你想得美。'],
    ['Good news.', '好消息。'],
    ['Poor thing.', '真可怜。'],
    ['Bless you.', '祝你平安。'],
    ['For what?', '为了什么？'],
    ['What happened?', '发生什么事了？'],
  ],
  cheerup: [
    ['Nailed it.', '漂亮，搞定了。'],
    ['Killed it.', '太厉害了。'],
    ['Well done.', '做得好。'],
    ['Nice one.', '漂亮。'],
    ['Good idea.', '好主意。'],
    ['Have faith.', '要有信心。'],
    ['Stay strong.', '坚强点。'],
    ['Stay cool.', '保持冷静。'],
    ['Stay true.', '做真实的自己。'],
    ['Stay focused.', '专注一点。'],
    ['Chin up.', '振作起来。'],
    ['Look ahead.', '往前看。'],
    ['Dream big.', '敢想敢做。'],
    ['Take chances.', '勇于尝试。'],
    ['Almost there.', '快到了。'],
    ["Don't worry.", '别担心。'],
    ['Cheer up.', '振作点。'],
    ['Good luck.', '祝你好运。'],
  ],
  mood: [
    ['Go easy.', '温和点，别太较真。'],
    ['Drop it.', '别说了，放下吧。'],
    ['Leave it.', '别管了。'],
    ['Let go.', '放手吧。'],
    ['Back off.', '退后，别逼我。'],
    ['Hands off.', '别碰。'],
    ['Get serious.', '认真点。'],
    ["Don't rush.", '别着急。'],
    ['Chill out.', '冷静点，放松。'],
    ['Be patient.', '耐心点。'],
    ['Be quiet.', '安静点。'],
    ['Keep silent.', '保持安静。'],
    ['Be careful.', '小心点。'],
    ['Get lost.', '走开。'],
    ['Shut up.', '闭嘴。'],
    ['Bite me.', '少理我。'],
    ['Screw you.', '去你的。'],
    ['Big Mouth.', '大嘴巴，多嘴。'],
  ],
  decide: [
    ['It depends.', '看情况。'],
    ['Suit yourself.', '随你便。'],
    ['Why bother.', '何必呢。'],
    ["I'm in.", '算我一个。'],
    ['I quit.', '我不干了。'],
    ['I decline.', '我拒绝。'],
    ['I agree.', '我同意。'],
    ['I disagree.', '我不同意。'],
    ['Give up.', '放弃吧。'],
    ['Try again.', '再试一次。'],
    ['Move on.', '继续往前吧。'],
    ['Right now.', '就现在。'],
    ['Not today.', '今天不行。'],
  ],
  reactions: [
    ['For real.', '说真的，真的吗？'],
    ['No cap.', '不骗你，说真的。'],
    ['It happens.', '常有的事。'],
    ['Fair enough.', '说得也是。'],
    ['No offense.', '无意冒犯。'],
    ['No biggie.', '没什么大不了。'],
    ['No sweat.', '小意思。'],
    ['No doubt.', '毫无疑问。'],
    ['No wonder.', '怪不得。'],
    ['My bad.', '我的错。'],
    ['All good.', '一切都好。'],
    ['Too bad.', '太可惜了。'],
    ['You bet.', '当然，没错。'],
    ["I'll say.", '我也这么认为。'],
    ["I'm flattered.", '过奖了。'],
    ["It's impossible.", '这不可能。'],
  ],
  mealtime: [
    ['Bottoms up.', '干杯。'],
    ['For here.', '在这儿吃。'],
    ['To go.', '带走。'],
  ],
  phone: [
    ['Hang up.', '挂电话吧。'],
  ],
  timetry: [
    ['One second.', '稍等一下。'],
    ['Time flies.', '光阴似箭。'],
  ],
  cominggoing: [
    ['Get ready.', '准备好了吗？'],
  ],
  promises: [
    ['Believe me.', '相信我。'],
  ],
  clarity: [
    ['Long story.', '说来话长。'],
    ['Joking aside.', '说正经的。'],
    ['Answer me.', '回答我。'],
  ],
};

const data = JSON.parse(fs.readFileSync(DATA, 'utf8'));
const before = data.groups.reduce((s, g) => s + g.items.length, 0);

const seen = new Set();
data.groups.forEach(g => g.items.forEach(it => seen.add(norm(it.en))));

let added = 0, skipped = 0;
const skippedList = [];

const push = (group, raw) => {
  raw.forEach(([en, name]) => {
    if (seen.has(norm(en))) { skipped++; skippedList.push(en); return; }
    seen.add(norm(en));
    group.items.push({ en, name });
    added++;
  });
};

Object.entries(extend).forEach(([gid, raw]) => {
  const g = data.groups.find(x => x.id === gid);
  if (!g) throw new Error('找不到分组：' + gid);
  push(g, raw);
});

const existIds = new Set(data.groups.map(g => g.id));
newGroups.forEach(ng => {
  if (existIds.has(ng.id)) throw new Error('分组 id 已存在：' + ng.id);
  const g = { id: ng.id, name: ng.name, en: ng.en, icon: ng.icon, items: [] };
  push(g, ng.items);
  data.groups.push(g);
});

fs.writeFileSync(DATA, JSON.stringify(data, null, 2), 'utf8');

const after = data.groups.reduce((s, g) => s + g.items.length, 0);
console.log('原有 ' + before + ' 句 → 现在 ' + after + ' 句（新增 ' + added + '）');
console.log('跳过重复 ' + skipped + ' 句' + (skippedList.length ? '：' + skippedList.join(' / ') : ''));
console.log('分组 ' + data.groups.length + ' 组');
