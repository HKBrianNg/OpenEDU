/**
 * YouTube json3 字幕 → 连贯英文句子列表。
 *   node _probe_sentences.cjs <xxx.json3> [输出文件]
 *
 * json3 是为「逐字滚动」服务的，拿来当句子看要先过三关：
 *   1) 每个 cue 只有半句，相邻 cue 大量重叠
 *   2) YouTube 现在是滚动刷新的，同一段话会按不同窗口重复吐好几遍
 *   3) ASR 常常不带标点、全小写，还混着 [Music] 这类背景说明
 */
const fs = require('fs');

const src = process.argv[2];
const out = process.argv[3];

const j = JSON.parse(fs.readFileSync(src, 'utf8'));

// 取文本，丢掉空的、纯换行的、[Music] 这类背景说明
const cues = (j.events || [])
  .map(e => (e.segs || []).map(s => s.utf8).join(''))
  .map(s => s.replace(/\s+/g, ' ').trim())
  .filter(s => s.length > 0)
  .filter(s => !/^\[[^\]]*\]$/.test(s));

/**
 * 去掉滚动字幕的重叠。
 * 关键观察：滚动窗口里「后一句常常整句重复前一句」，或者和前一句尾部重叠。
 * 所以只有当新片段带着新内容时，才把新多出来的部分接上去。
 */
function stitch(list) {
  const merged = [];
  for (const piece of list) {
    const prev = merged[merged.length - 1];
    if (!prev) {
      merged.push(piece);
      continue;
    }
    // 完全重复（含「上一句是这一句的开头」这种包含关系）
    if (prev === piece || prev.endsWith(piece) || piece.endsWith(prev)) {
      // 保留更长的那个，避免丢内容
      if (piece.length > prev.length) merged[merged.length - 1] = piece;
      continue;
    }
    // 尾部与头部有重叠：只追加多出来的部分
    let overlap = 0;
    const max = Math.min(prev.length, piece.length);
    for (let n = 1; n <= max; n++) {
      if (prev.slice(-n) === piece.slice(0, n)) overlap = n;
    }
    if (overlap > 0) {
      merged[merged.length - 1] = prev + piece.slice(overlap);
      continue;
    }
    merged.push(piece);
  }
  return merged;
}

let sentences = stitch(cues);

// 转成看着像句子的样子：首字母大写、结尾补句号
sentences = sentences
  .map(s => s.trim())
  .filter(Boolean)
  .map(s => {
    let t = s.charAt(0).toUpperCase() + s.slice(1);
    if (!/[.!?]$/.test(t)) t += '.';
    return t;
  });

const raw = sentences.join('\n');
console.log(`cue ${cues.length} 条 → 句子 ${sentences.length} 条`);
console.log(`字符数 ${raw.length}`);
if (out) fs.writeFileSync(out, raw + '\n', 'utf8');
console.log('');
console.log('=== 前 40 条预览 ===');
sentences.slice(0, 40).forEach((s, i) => console.log(String(i + 1).padStart(3) + '. ' + s));
