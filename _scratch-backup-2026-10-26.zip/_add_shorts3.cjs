// _add_shorts3.cjs —— 第三个视频的短句合并进 EnglishShorts/data.json
//
// 相比 _add_shorts.cjs：去重前先展开缩写（You're → You are），
// 否则 "You are the best." 会和已有的 "You're the best." 重复收录。
// 另手动跳过 "Hard to tell."，书里已有同义的 "It's hard to tell."。

const fs = require('fs');
const path = require('path');
const DATA = path.join(__dirname, 'public/data/EnglishShorts/data.json');

const RE = [
  [/you're/gi, 'you are'], [/i'm/gi, 'i am'], [/it's/gi, 'it is'],
  [/that's/gi, 'that is'], [/don't/gi, 'do not'], [/can't/gi, 'cannot'],
  [/didn't/gi, 'did not'], [/doesn't/gi, 'does not'], [/isn't/gi, 'is not'],
  [/i'll/gi, 'i will'], [/i'd/gi, 'i would'], [/i've/gi, 'i have'],
  [/we're/gi, 'we are'], [/let's/gi, 'let us'], [/how's/gi, 'how is'],
  [/what's/gi, 'what is'], [/who's/gi, 'who is'],
];
const norm = s => {
  let t = String(s);
  RE.forEach(([re, to]) => { t = t.replace(re, to); });
  return t.toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, ' ').trim();
};

const newGroups = [
  { id: 'promises', name: '承诺与交情', en: 'Promises & Favors', icon: '🤝', items: [
    ['I owe you one.', '我欠你一个人情。'],
    ['You have my word.', '我向你保证。'],
    ["It's a deal.", '一言为定。'],
    ['We are even.', '我们扯平了。'],
    ['Count me in.', '算我一个。'],
    ['I mean it.', '我是认真的。'],
    ['As you wish.', '如你所愿。'],
  ]},
  { id: 'sides', name: '站队与认同', en: 'Taking Sides', icon: '🙋', items: [
    ["I'm with you.", '我跟你一起。'],
    ["I'm on your side.", '我站在你这边。'],
    ["You're the boss.", '你说了算。'],
    ['Same to you.', '你也一样。'],
    ['Ladies first.', '女士优先。'],
    ['Is this seat taken?', '这个位子有人吗？'],
  ]},
  { id: 'clarity', name: '把话说清楚', en: 'Getting Clear', icon: '🗣️', items: [
    ['Speak up.', '大点声说。'],
    ['Long story short.', '长话短说。'],
    ['Change the subject.', '换个话题吧。'],
    ["Don't you see?", '你还不明白吗？'],
    ['Get out of here.', '少来了，别开玩笑了。'],
  ]},
];

const extend = {
  checkingin: [
    ['Are you all right?', '你没事吧？'],
    ["I don't feel good.", '我不太舒服。'],
    ['Your fly is down.', '你裤子拉链没拉。'],
  ],
  phone: [
    ['My phone died.', '我手机没电了。'],
    ['The line is busy.', '电话占线。'],
    ['Who is this?', '你是谁？'],
  ],
  smalltalk: [
    ['Good to see you.', '见到你很高兴。'],
    ['You too.', '你也是。'],
    ['Talk to you later.', '回头再聊。'],
    ['Catch you later.', '回头见。'],
    ['How did it go?', '进行得怎么样？'],
    ['Speak of the devil.', '说曹操曹操到。'],
    ["You don't say.", '真的吗？不会吧。'],
    ['Am I right?', '我说得对吧？'],
  ],
  cheerup: [
    ['Go for it.', '放手去做吧。'],
    ["I'm behind you.", '我支持你。'],
    ['Hang in there.', '坚持住。'],
    ['You win.', '你赢了。'],
  ],
  handy: [
    ['Just a moment.', '稍等一下。'],
    ["I'm on my way.", '我在路上了。'],
    ['I get it.', '我懂了。'],
    ['Are you ready?', '你准备好了吗？'],
    ['Can we make it?', '我们来得及吗？'],
    ["Don't rush me.", '别催我。'],
    ["That's enough.", '够了。'],
    ['Enough is enough.', '适可而止。'],
    ['Skip it.', '跳过吧，算了。'],
    ['Thanks for coming.', '谢谢你能来。'],
    ['This is it.', '就是这个。'],
  ],
  decide: [
    ['Make up your mind.', '拿定主意吧。'],
    ['Give it a try.', '试一试。'],
    ['Whatever you say.', '随你说吧。'],
    ['Anything you say.', '你说什么都行。'],
    ['Fine with me.', '我没意见。'],
    ['Works for me.', '我这边没问题。'],
    ['Take it or leave it.', '要不要随你。'],
    ['Not a chance.', '没门儿。'],
    ["It isn't worth it.", '不值得。'],
    ['The sooner the better.', '越快越好。'],
  ],
  reactions: [
    ['I guess so.', '我想是吧。'],
    ['Are you sure?', '你确定吗？'],
    ['Are you serious?', '你是认真的吗？'],
    ['I doubt that.', '我表示怀疑。'],
    ['Believe it or not.', '信不信由你。'],
    ['No such thing.', '没这回事。'],
    ["It's nothing.", '没什么，小事一桩。'],
    ["It's all good.", '一切都好，没事。'],
    ["That's not fair.", '这不公平。'],
    ['Get real.', '现实点吧。'],
    ["You're telling me.", '可不是嘛。'],
    ['Over my dead body.', '我死也不同意。'],
    ["I don't wonder.", '我一点也不奇怪。'],
  ],
  trouble: [
    ['I messed up.', '我搞砸了。'],
    ["It's killing me.", '真是要命。'],
    ["I'm sick of it.", '我受够了。'],
    ['That sucks.', '真糟糕。'],
  ],
  timetry: [
    ['What day is it today?', '今天星期几？'],
    ['Today is Friday.', '今天是星期五。'],
    ['Are you in line?', '你在排队吗？'],
    ["Let's call it a day.", '今天就到这儿吧。'],
  ],
  mealtime: [
    ['For here or to go?', '在这儿吃还是带走？'],
  ],
  visiting: [
    ['Be my guest.', '请便，别客气。'],
    ['Thanks a million.', '万分感谢。'],
    ['All the best.', '祝你一切顺利。'],
  ],
  mood: [
    ['Cut it out.', '别闹了，住手。'],
    ['Watch your mouth.', '说话注意点。'],
    ['Bite your tongue.', '忍住别说。'],
    ["Don't even try it.", '想都别想。'],
    ['Say no more.', '别再说了。'],
    ['Act your age.', '别孩子气了。'],
    ["Don't be silly.", '别傻了。'],
    ['Shame on you.', '真不害臊。'],
    ["Don't bother.", '别费心了。'],
    ['Give it up.', '放弃吧，别白费劲了。'],
    ['You asked for it.', '你自找的。'],
  ],
};

const data = JSON.parse(fs.readFileSync(DATA, 'utf8'));
const before = data.groups.reduce((s, g) => s + g.items.length, 0);

const seen = new Set();
data.groups.forEach(g => g.items.forEach(it => seen.add(norm(it.en))));

let added = 0, skipped = 0;
const skippedList = [];

const push = (group, raw) => {
  raw.forEach(([en, name]) => {
    if (seen.has(norm(en))) { skipped++; skippedList.push(en); return; }
    seen.add(norm(en));
    group.items.push({ en, name });
    added++;
  });
};

Object.entries(extend).forEach(([gid, raw]) => {
  const g = data.groups.find(x => x.id === gid);
  if (!g) throw new Error('找不到分组：' + gid);
  push(g, raw);
});

const existIds = new Set(data.groups.map(g => g.id));
newGroups.forEach(ng => {
  if (existIds.has(ng.id)) throw new Error('分组 id 已存在：' + ng.id);
  const g = { id: ng.id, name: ng.name, en: ng.en, icon: ng.icon, items: [] };
  push(g, ng.items);
  data.groups.push(g);
});

fs.writeFileSync(DATA, JSON.stringify(data, null, 2), 'utf8');

const after = data.groups.reduce((s, g) => s + g.items.length, 0);
console.log('原有 ' + before + ' 句 → 现在 ' + after + ' 句（新增 ' + added + '）');
console.log('跳过重复 ' + skipped + ' 句' + (skippedList.length ? '：' + skippedList.join(' / ') : ''));
console.log('分组 ' + data.groups.length + ' 组');
