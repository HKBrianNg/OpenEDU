// _audit.cjs —— 扫全书，把「可能不适合孩子学」或「可能本身就不对」的句子列出来
const fs = require('fs');
const j = JSON.parse(fs.readFileSync('public/data/EnglishShorts/data.json', 'utf8'));

// 粗俗 / 骂人 / 涉及隐私 / 太新的俚语 / 语义可疑
const RISK = [
  [/screw/i, '粗俗'],
  [/sucks/i, '轻度粗话'],
  [/damn|hell/i, '脏话'],
  [/shut up/i, '骂人'],
  [/get lost/i, '骂人'],
  [/bite me/i, '骂人'],
  [/\bbig mouth\b/i, '说人缺点'],
  [/stupid|idiot|dumb/i, '骂人'],
  [/hate/i, '负面'],
  [/fly is down/i, '涉及隐私'],
  [/\bno cap\b/i, '太新的俚语'],
  [/dead body|drop dead/i, '带死字'],
  [/i don'?t wonder/i, '非标准用法'],
  [/kill(ing)? me/i, '语义含糊'],
  [/shame on you/i, '指责'],
  [/you asked for it/i, '刻薄'],
  [/back off|hands off/i, '有攻击性'],
  [/\bquit\b|\bgive up\b/i, '消极'],
  [/lose|loser/i, '负面'],
];

const hits = [];
j.groups.forEach(g => g.items.forEach(it => {
  RISK.forEach(([re, why]) => {
    if (re.test(it.en)) hits.push({ g: g.name, icon: g.icon, en: it.en, name: it.name, why });
  });
}));

const uniq = [];
const seen = new Set();
hits.forEach(h => {
  const k = h.en;
  if (seen.has(k)) return;
  seen.add(k);
  uniq.push(h);
});

console.log('全书 ' + j.groups.reduce((s, g) => s + g.items.length, 0) + ' 句，命中可疑 ' + uniq.length + ' 句：');
console.log('');
uniq.forEach((h, i) => {
  console.log(String(i + 1).padStart(3) + '. [' + h.why + '] ' + h.en.padEnd(30) + ' → ' + h.name + '   （' + h.icon + h.g + '）');
});
