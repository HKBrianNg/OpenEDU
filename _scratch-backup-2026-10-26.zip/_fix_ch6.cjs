/**
 * 补 BasicEnglish300 缺失数据的一次性脚本。
 *
 * 背景：第六章「在卫生间」items 为空，它指向的 lessonsFile「bathroom.json」在仓库里
 * 根本没有（dist 里只剩下图的产物），但 content/ 下 30 张卫生间的配图都在。
 * 图片文件名本身就是句子，据此还原；顺便把两张被漏掉的场景图归位。
 *
 * 用法： node _fix_ch6.cjs
 */
const fs = require('fs');

const DATA = 'public/data/BasicEnglish300/data.json';
const CONTENT = 'public/data/BasicEnglish300/content';

// 第六章：在卫生间。按真实动线排序 —— 上厕所 → 洗手 → 刷牙 → 洗澡 → 擦干。
// 英文一律教学优先：TP 写成 toilet paper，缩写小孩看不懂。
const BATHROOM = [
  ['你要上厕所吗？', 'Do you need to go to the bathroom?', 'do-you-need-to-go-to-the-bathroom.jpg'],
  ['要上厕所就告诉妈妈。', 'Tell Mom if you need to go to the bathroom.', 'tell-mom-if-you-need-to-go-to-the-bathroom.jpg'],
  ['卫生间里没纸了。', "There's no toilet paper in the bathroom.", 'there-is-no-tp-in-the-bathroom.jpg'],
  ['把裤子脱下来。', 'Pull your pants down.', 'pull-your-pants-down.jpg'],
  ['把马桶圈掀起来。', 'Lift up the toilet seat.', 'lift-up-the-toilet-seat.jpg'],
  ['拿点纸，擦擦小屁股。', 'Get some toilet paper and wipe your bottom.', 'get-some-tp-and-wipe-your-bottom.jpg'],
  ['来，我给你擦屁股。', "Here, I'll wipe your bottom.", 'here-ill-wipe-your-bottom.jpg'],
  ['擦干净了吗？', 'Did you wipe clean?', 'did-you-wipe-clean.jpg'],
  ['哎呀，好臭！', 'Oh, that stinks!', 'oh-that-stinks.jpg'],
  ['记得冲马桶。', 'Remember to flush the toilet.', 'remember-to-flush-the-toilet.jpg'],
  ['把马桶圈放下来。', 'Put the toilet seat down.', 'put-the-toilet-seat-down.jpg'],
  ['用洗手液洗洗手。', 'Wash your hands with soap.', 'wash-your-hands-with-soap.jpg'],
  ['把手擦干。', 'Dry your hands off.', 'dry-your-hands-off.jpg'],
  ['把水龙头关到底。', 'Turn the tap off all the way.', 'turn-the-tap-off-all-the-way.jpg'],
  ['用抹布把台面擦干净。', 'Wipe the countertop off with a cloth.', 'wipe-the-countertop-off-with-a-cloth.jpg'],
  ['把毛巾拧干。', 'Wring out the towel.', 'wring-out-the-towel.jpg'],
  ['该刷牙了。', "It's time to brush your teeth.", 'its-time-to-brush-your-teeth.jpg'],
  ['挤点牙膏出来。', 'Squeeze some toothpaste out.', 'squeeze-some-toothpaste-out.jpg'],
  ['好好刷牙。', 'Brush your teeth right.', 'brush-your-teeth-right.jpg'],
  ['漱漱口，咕噜咕噜。', 'Gargle and swish.', 'gargle-and-swish.jpg'],
  ['我们去洗澡吧。', "Let's take a shower.", 'lets-go-shower.jpg'],
  ['给你洗发水。', "Here's some shampoo for you.", 'heres-some-shampoo-for-you.jpg'],
  ['别玩水。', "Don't play with the water.", 'dont-play-with-the-water.jpg'],
  ['我来帮你擦干。', 'Let me help you dry off.', 'let-me-help-you-dry-off.jpg'],
  ['用吹风机把头发吹干。', 'Dry your hair with the hair dryer.', 'dry-your-hair-with-the-hair-dryer.jpg'],
  ['往身上擦点润肤露。', 'Put some lotion on your body.', 'put-some-lotion-on-your-body.jpg'],
  ['你这个小淘气！', 'You cheeky monkey!', 'you-cheeky-monkey.jpg'],
];

// 混在孤立图里、其实不属于卫生间的两张，归到各自该去的章节。
const STRAYS = {
  '第五章：在厨房': [['帮我把盐拿来。', 'Get the salt for me, please.', 'get-the-salt-for-me-please.jpg']],
};

const j = JSON.parse(fs.readFileSync(DATA, 'utf8'));
const imgs = fs.readdirSync(CONTENT);
const toItem = ([name, en, lessonImage]) => ({ name, en, lessonImage });

let added = 0;
let missing = [];

// 第六章
const ch6 = j.chapters.find((c) => c.name.startsWith('第六章'));
if (!ch6) throw new Error('找不到第六章');
if (ch6.items.length) throw new Error(`第六章已有 ${ch6.items.length} 条，拒绝覆盖`);

for (const row of BATHROOM) {
  if (!imgs.includes(row[2])) missing.push(row[2]);
}
ch6.items = BATHROOM.map(toItem);
added += BATHROOM.length;

// 归位的图
for (const [chapName, rows] of Object.entries(STRAYS)) {
  const ch = j.chapters.find((c) => c.name === chapName);
  if (!ch) throw new Error('找不到' + chapName);
  for (const row of rows) {
    if (ch.items.some((x) => x.lessonImage === row[2])) continue;
    if (!imgs.includes(row[2])) missing.push(row[2]);
    ch.items.push(toItem(row));
    added += 1;
  }
}

if (missing.length) {
  console.log('✗ 以下图片不存在，已中止：');
  missing.forEach((m) => console.log('   ' + m));
  process.exit(1);
}

// 第六章丢了 lessonsFile 指向的文件，留着会让后人以为数据还在别处
delete ch6.lessonsFile;

fs.writeFileSync(DATA, JSON.stringify(j, null, 2) + '\n', 'utf8');
console.log(`写入 ${added} 条`);
