// 从 52 集台词里提取词汇基础数据：词元、频次、例句、出处集
// 输出 _vocab-base.json（缺中文释义，释义由人工分批补到 _gloss-*.json）
const fs = require('fs');
const path = require('path');

const base = 'public/data/EnglishVideo/Kingdergarten';
const dir = path.join(base, 'transcripts');
const grade = JSON.parse(fs.readFileSync(path.join(base, 'Kingdergarten.json'), 'utf8'));

const STOP = new Set(['a','an','the','is','am','are','was','were','be','been','being','to','of','in','on','at','for','with','and','or','but','so','as','by','from','up','down','out','off','over','into','than','too','very','just','also','not','no','yes','i','you','he','she','it','we','they','me','him','her','us','them','my','your','his','its','our','their','this','that','these','those','here','there','now','then','do','does','did','can','will','would','could','should','shall','may','might','must','have','has','had','oh','hey','hi','hello','yeah','ok','okay','s','t','m','d','ll','re','ve',
// 缩写：不是生字，且无法干净还原
'i\'m','it\'s','that\'s','what\'s','there\'s','he\'s','she\'s','who\'s','how\'s',
'we\'re','you\'re','they\'re','let\'s','don\'t','isn\'t','aren\'t','can\'t','won\'t',
'didn\'t','doesn\'t','wasn\'t','weren\'t','haven\'t','hasn\'t','i\'ve','you\'ve','we\'ve',
'i\'ll','you\'ll','he\'ll','we\'ll','that\'ll','i\'d','you\'d','he\'d','we\'d']);

const IRREG = {went:'go',gone:'go',came:'come',ate:'eat',eaten:'eat',saw:'see',seen:'see',got:'get',gotten:'get',made:'make',took:'take',taken:'take',said:'say',ran:'run',put:'put',children:'child',teeth:'tooth',feet:'foot',mice:'mouse',men:'man',women:'woman',done:'do',gave:'give',given:'give',threw:'throw',thrown:'throw',fell:'fall',fallen:'fall',flew:'fly',flown:'fly',blew:'blow',known:'know',grew:'grow',drew:'draw',swam:'swim',sang:'sing',began:'begin',drunk:'drink',hid:'hide',rode:'ride',wrote:'write',woke:'wake',broke:'break',spoke:'speak',stood:'stand',found:'find',bought:'buy',brought:'bring',thought:'think',caught:'catch',taught:'teach',left:'leave',lost:'lose',won:'win',meant:'mean',built:'build',sent:'send',spent:'spend',slept:'sleep',kept:'keep',felt:'feel',met:'meet',fed:'feed',led:'lead',read:'read',hurt:'hurt',cut:'cut',shut:'shut',set:'set',sat:'sit',understood:'understand'};

const KNOWN_V = ['like','love','make','take','give','come','have','dance','bounce','chase','hide','ride','slide','wave','save','move','use','close','share','care','smile','tidy','hurry','carry','worry','try','fly','cry','dry','bake','shake','wake','breathe','cycle','juggle','tickle','wriggle','write','bite','drive','arrive','surprise','exercise','practise','measure','treasure','bore','score','store','more','sure','cure','pure','figure','picture','nature','future','mixture'];

const DBL = new Set(['running','swimming','sitting','getting','cutting','hitting','jogging','shopping','stopping','planning','hugging','digging','putting','winning','beginning','dropping','clapping','stepping','mopping','nodding','stopped','planned','hugged','jogged','shopped','clapped','stepped','dropped','grabbed','nodded']);

function lemma(w) {
  if (IRREG[w]) return IRREG[w];
  // 缩写不参与还原：it's 会被 -s 规则切成 it'，don't/let's 同理
  if (w.includes("'")) return w;
  if (w.length <= 3) return w;
  if (w.endsWith('ies') && w.length > 4) return w.slice(0, -3) + 'y';
  if (w.endsWith('ing')) {
    const stem = w.slice(0, -3);
    if (stem.length >= 3) {
      if (DBL.has(w)) return stem.slice(0, -1);
      const withE = stem + 'e';
      if (KNOWN_V.includes(withE)) return withE;
      return stem;
    }
  }
  if (w.endsWith('ed')) {
    const stem = w.slice(0, -2);
    if (stem.length >= 3) {
      if (DBL.has(w)) return stem.slice(0, -1);
      if (stem.endsWith('i')) return stem.slice(0, -1) + 'y';
      const withE = stem + 'e';
      if (KNOWN_V.includes(withE)) return withE;
      return stem;
    }
  }
  if (w.endsWith('s') && !w.endsWith('ss') && !w.endsWith('us') && !w.endsWith('is')) {
    const stem = w.slice(0, -1);
    if (stem.length >= 3) {
      const withE = stem + 'e';
      if (KNOWN_V.includes(withE)) return withE;
      return stem;
    }
  }
  return w;
}

/**
 * 从一整句台词里切出包含该词的最短子句。
 * 台词里有些句子是一整段剧情（200+ 字符），直接当例句没法看。
 */
function bestClause(sentence, word) {
  // 句子本身不长就整句用：切子句会让中文翻译跟英文对不上（中文是整句译的）
  if (sentence.length <= 110) return sentence;
  const parts = sentence.split(/(?<=[.!?])\s+/);
  const hits = parts.filter((p) => p.toLowerCase().includes(word.toLowerCase()));
  if (hits.length === 0) return sentence;
  return hits.reduce((a, b) => (a.length <= b.length ? a : b));
}

/**
 * 例句打分（越小越好）。不能只看短 —— 最短的子句往往是 "Pig." "Dinosaur!"
 * 这种没有语境的碎片，也可能撞上自动字幕的语法错误残句。
 * 目标是 70 字符左右、有完整语境、且词以原形出现的句子。
 */
function scoreClause(clause, word) {
  const bare = clause.toLowerCase().replace(/[^a-z']/g, '');
  // 整句就等于这个词本身（去掉标点后）→ 毫无语境，重罚
  if (bare === word.toLowerCase() || bare === word.toLowerCase() + 's') return 1000 + clause.length;
  let s = Math.abs(clause.length - 70);
  if (clause.length < 18) s += 120; // 太短：没语境
  if (clause.length > 130) s += 60; // 太长：读不完
  if (!clause.toLowerCase().includes(word.toLowerCase())) s += 30; // 词以变形出现
  return s;
}

const freq = new Map();
const ex = new Map();
const eps = new Map();
const forms = new Map(); // lemma -> 出现的词形集合

for (const it of grade.items) {
  if (!it.transcriptFile) continue;
  const p = path.join(dir, path.basename(it.transcriptFile));
  if (!fs.existsSync(p)) continue;
  const lines = JSON.parse(fs.readFileSync(p, 'utf8')).lines || [];
  for (const l of lines) {
    if (!l.en) continue;
    const words = (l.en.match(/[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ'’-]*/g) || []).map(w => w.toLowerCase().replace(/[’']/g, "'"));
    for (const raw of words) {
      if (raw.length < 3) continue;
      if (STOP.has(raw)) continue;
      // 不做词形还原。试过：规则误伤太严重，会造出 someth/glasse/tomatoe/wedd
      // 这类假词（something/glasses/tomatoes/wedding 被 -s/-ed/-ing 规则削掉尾巴）。
      // 宁可 puddle 和 puddles 各占一条，也不能让生字表里出现不存在的词。
      const lm = raw;
      freq.set(lm, (freq.get(lm) || 0) + 1);
      if (!forms.has(lm)) forms.set(lm, new Set());
      forms.get(lm).add(raw);
      if (!eps.has(lm)) eps.set(lm, new Set());
      eps.get(lm).add(it.id);
      // 用完整句，不切子句：中文是按整句译的，切了英文就对不上中文。
      // 长句靠 scoreClause 的惩罚项自然排在后面，不会优先选中。
      const clause = l.en;
      const score = scoreClause(clause, lm);
      const cur = ex.get(lm);
      if (!cur || score < cur.score) {
        ex.set(lm, {
          en: clause,
          zh: l.zh,
          score,
          epId: it.id,
          epName: it.englishName,
          epZh: it.chineseName,
        });
      }
    }
  }
}

const words = [...freq.keys()]
  .sort((a, b) => freq.get(b) - freq.get(a))
  .map(w => ({
    w,
    freq: freq.get(w),
    ex: ex.get(w).en,
    exZh: ex.get(w).zh,
    epId: ex.get(w).epId,
    epName: ex.get(w).epName,
    epZh: ex.get(w).epZh,
    eps: [...eps.get(w)].sort((a, b) => a - b),
    forms: [...forms.get(w)].sort(),
  }));

fs.writeFileSync('_vocab-base.json', JSON.stringify(words, null, 1), 'utf8');
console.log('词条数: ' + words.length);
console.log('总频次: ' + words.reduce((s, x) => s + x.freq, 0));
console.log('');
console.log('--- 前 12 条样例 ---');
for (const x of words.slice(0, 12)) {
  console.log(`${x.w} | freq=${x.freq} | eps=${x.epCount} | forms=${x.forms.join('/')}`);
  console.log(`   ex: ${x.ex}`);
}
console.log('');
console.log('--- 后 8 条(低频) ---');
for (const x of words.slice(-8)) {
  console.log(`${x.w} | freq=${x.freq} | ex: ${x.ex}`);
}
