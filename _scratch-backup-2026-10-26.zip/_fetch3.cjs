// 临时：按仪表板导出的清单抓取字幕并转成台词 JSON
// 用法：
//   node _fetch3.cjs fetch   _tasks.json   抓字幕到 _subs3/
//   node _fetch3.cjs convert _tasks.json   转成 transcripts/*.json（zh 留空待补）
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const YT = 'C:\\Users\\brian\\AppData\\Roaming\\Python\\Python314\\Scripts\\yt-dlp.exe';
const SUBS = '_subs3';
/** 两次请求之间的间隔；不留间隔会撞 YouTube 的 HTTP 429 */
const GAP_MS = Number(process.env.SUB_GAP_MS || 2500);
/** 用 Atomics 做同步等待：node 没有内置的阻塞 sleep */
function sleepSync(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}

const mode = process.argv[2] || 'fetch';
const taskFile = process.argv[3] || '_tasks.json';
const tasks = JSON.parse(fs.readFileSync(taskFile, 'utf8'));
const items = (tasks.items || []).filter((x) => x.url && /[?&]v=/.test(x.url));

/** 秒 → mm:ss */
function fmt(ms) {
  const s = Math.floor(ms / 1000);
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
}

function vidOf(url) {
  const m = url.match(/[?&]v=([A-Za-z0-9_-]{11})/);
  return m ? m[1] : null;
}

// ---------- 抓取 ----------
function fetchAll() {
  fs.mkdirSync(SUBS, { recursive: true });
  let ok = 0;
  const failed = [];
  for (const it of items) {
    const vid = vidOf(it.url);
    const out = path.join(SUBS, `${vid}.en.json3`);
    if (fs.existsSync(out)) {
      ok++;
      console.log(`#${it.id} ${vid} 已存在`);
      continue;
    }
    try {
      sleepSync(GAP_MS); // 连续请求会撞 HTTP 429，每次抓之前先歇一下
      // 人工字幕优先：--write-subs 取不到时 --write-auto-subs 兜底
      // 注意别用 'en.*'：TED-Ed 有十几种字幕，通配会把它们全拉下来，
      // 拉到第二个就 429，最后连第一个 en 都拿不到。只取英文。
      execFileSync(
        YT,
        ['--write-subs', '--write-auto-subs', '--skip-download', '--sub-lang', 'en',
         '--sub-format', 'json3', '--extractor-args', 'youtube:player_client=android',
         '-o', path.join(SUBS, `${vid}.%(ext)s`), '--no-warnings',
         `https://www.youtube.com/watch?v=${vid}`],
        { encoding: 'utf8', timeout: 120000, stdio: 'pipe' },
      );
      if (fs.existsSync(out)) {
        ok++;
        console.log(`#${it.id} ${vid} ✓ ${it.titleZh}`);
      } else {
        // 人工字幕会存成 .en.json3，自动字幕可能是 .en-en.json3
        const alt = fs.readdirSync(SUBS).filter((f) => f.startsWith(vid) && f.endsWith('.json3'));
        if (alt.length) {
          fs.copyFileSync(path.join(SUBS, alt[0]), out);
          ok++;
          console.log(`#${it.id} ${vid} ✓（用 ${alt[0]}）`);
        } else {
          failed.push(`#${it.id} ${it.titleZh}`);
          console.log(`#${it.id} ${vid} 无字幕`);
        }
      }
    } catch (e) {
      failed.push(`#${it.id} ${it.titleZh}`);
      console.log(`#${it.id} ${vid} 失败`);
    }
  }
  console.log(`\n成功 ${ok} / ${items.length}` + (failed.length ? ` | 失败: ${failed.join(', ')}` : ''));
}

/**
 * json3 → 台词行。字幕片段是按词切的，直接一行一句太碎，
 * 按「句子结束符 + 停顿间隔 + 长度上限」合并成自然的一行。
 */
/** 版权声明/网址不是台词，滤掉；但它们常跟标题挤在同一行，所以只切后半句 */
const SKIP = /fable\s*cottage|original tale|version of the tale|subtitles? by|www\./i;

/** 去掉行里的版权尾巴，返回剩余的正文（整行都是版权则返回空串） */
function stripCredit(s) {
  if (!SKIP.test(s)) return s;
  const head = s.split(/fable\s*cottage|[Aa] (?:version|original) of|subtitles? by|www\./i)[0];
  return head.replace(/[\s.,;:]+$/, '').trim();
}

function toLines(j) {
  const evs = (j.events || []).filter((e) => e.segs);
  const out = [];
  let buf = '';
  let startMs = null;
  let lastEnd = null;

  /**
   * 收一行。buf 里常常攒了好几句（人工字幕一整段就是一个块），
   * 这里按句子边界切开，保证每行是一句完整的话——否则生字表的例句会断在半句上。
   * 时间戳按字符比例在这段里插值。
   */
  const flush = () => {
    const text = buf.replace(/\s+/g, ' ').trim();
    buf = '';
    const from = startMs;
    startMs = null;
    if (!text) return;
    const parts = text.match(/[^.!?]+[.!?]+["')\]]?|[^.!?]+$/g) || [text];
    const total = parts.reduce((s, p) => s + p.length, 0) || 1;
    const span = lastEnd !== null && from !== null ? Math.max(lastEnd - from, 0) : 0;
    let acc = 0;
    for (const p of parts) {
      const one = p.trim();
      if (one) out.push({ start: fmt((from || 0) + span * (acc / total)), en: one });
      acc += p.length;
    }
  };

  for (const e of evs) {
    const txt = e.segs.map((s) => s.utf8 || '').join('').replace(/\n/g, ' ');
    const clean = stripCredit(txt);
    if (!clean) continue;
    const end = (e.tStartMs || 0) + (e.dDurationMs || 0);
    // 间隔超过 1.5 秒视为新的一句
    if (buf && lastEnd !== null && e.tStartMs - lastEnd > 1500) flush();
    if (startMs === null) startMs = e.tStartMs;
    // 每个 event 是屏幕上独立出现的一块，直接拼会连成 windowwaiting
    if (buf && !/\s$/.test(buf) && !/^\s/.test(clean)) buf += ' ';
    buf += clean;
    lastEnd = end;
    // 句子结束就收一行；200 字符只是兜底，正常不会走到
    if (/[.!?]["')\]]?\s*$/.test(buf.trim()) || buf.length > 200) flush();
  }
  flush();

  return out.map((l, i) => ({ index: i + 1, start: l.start, en: l.en, zh: '' }));
}

// ---------- 转换 ----------
function convertAll() {
  let ok = 0;
  const missing = [];
  for (const it of items) {
    const vid = vidOf(it.url);
    const src = path.join(SUBS, `${vid}.en.json3`);
    if (!fs.existsSync(src)) {
      missing.push(`#${it.id} ${it.titleZh}（没抓到）`);
      continue;
    }
    const lines = toLines(JSON.parse(fs.readFileSync(src, 'utf8')));
    const target = path.join(tasks.dataRoot, it.targetPath.replace(/^public\/data\/EnglishVideo\//, ''));
    // 已经翻过的文件不覆盖：重跑转换是为了修合并逻辑，不能把人工翻译冲掉
    if (fs.existsSync(target)) {
      const old = JSON.parse(fs.readFileSync(target, 'utf8'));
      if ((old.lines || []).some((l) => l.zh)) {
        console.log(`#${it.id} ${it.titleZh} 已翻译，跳过`);
        continue;
      }
    }
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, JSON.stringify({ lines }, null, 2) + '\n', 'utf8');
    ok++;
    console.log(`#${it.id} ${it.titleZh.padEnd(12)} ${String(lines.length).padStart(3)} 行 → ${path.basename(target)}`);
  }
  console.log(`\n写出 ${ok} 个文件` + (missing.length ? ` | 缺: ${missing.join(', ')}` : ''));
}

if (mode === 'fetch') fetchAll();
else if (mode === 'convert') convertAll();
else console.log('用法: node _fetch3.cjs fetch|convert <清单.json>');
