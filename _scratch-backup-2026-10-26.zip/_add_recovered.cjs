// _add_recovered.cjs —— 补上第四集折叠失败漏掉的 3 句。
// 这几句在三连重复时被错开词序或插入 [Music]，严格匹配折不动，
// 回原始字幕确认过确实是视频里念的短语。
// Zip it. 同样确认是真的，但跟 Shut up. 一类，等用户决定要不要收。

const fs = require('fs');
const path = require('path');
const DATA = path.join(__dirname, 'public/data/EnglishShorts/data.json');

const add = {
  road: [['Follow me.', '跟我来。']],
  reactions: [['Kind of.', '有点儿，算是吧。']],
  handy: [["What's next?", '下一个是什么？']],
};

const data = JSON.parse(fs.readFileSync(DATA, 'utf8'));
let n = 0;
Object.entries(add).forEach(([gid, items]) => {
  const g = data.groups.find(x => x.id === gid);
  if (!g) throw new Error('找不到分组：' + gid);
  items.forEach(([en, name]) => {
    if (g.items.some(it => it.en.toLowerCase() === en.toLowerCase())) {
      console.log('已存在，跳过：' + en);
      return;
    }
    g.items.push({ en, name });
    n++;
  });
});

fs.writeFileSync(DATA, JSON.stringify(data, null, 2), 'utf8');
const total = data.groups.reduce((s, g) => s + g.items.length, 0);
console.log('补入 ' + n + ' 句 → 共 ' + total + ' 句');
