/** 检查台词文件：断句是否干净、有没有多句粘连、行长分布 */
const fs = require('fs');
const path = require('path');

const dir = process.argv[2];
const rows = [];
for (const f of fs.readdirSync(dir)) {
  if (!f.endsWith('.json')) continue;
  const j = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
  j.lines.forEach((l) => rows.push({ file: f, index: l.index, en: l.en, zh: l.zh }));
}

console.log('总行数 ' + rows.length);

// 一行里如果出现「句末标点 + 空格 + 大写字母开头」，说明多句没切开
const multi = rows.filter((r) => /[.!?]["')\]]?\s+[A-Z"“]/.test(r.en.slice(0, -1)));
console.log('疑似多句粘连的行: ' + multi.length);
multi.slice(0, 8).forEach((r) => {
  console.log('  [' + r.file + ' #' + r.index + '] ' + r.en.slice(0, 120));
});

const L = rows.map((r) => r.en.length).sort((a, b) => a - b);
console.log('');
console.log('行长: 最短 ' + L[0] + ' | 中位 ' + L[Math.floor(L.length / 2)] + ' | 最长 ' + L[L.length - 1]);
console.log('平均 ' + Math.round(rows.reduce((s, r) => s + r.en.length, 0) / rows.length) + ' 字符');

const buckets = { '<50': 0, '50-100': 0, '100-150': 0, '150-200': 0, '>200': 0 };
rows.forEach((r) => {
  const n = r.en.length;
  if (n < 50) buckets['<50']++;
  else if (n < 100) buckets['50-100']++;
  else if (n < 150) buckets['100-150']++;
  else if (n < 200) buckets['150-200']++;
  else buckets['>200']++;
});
console.log('分布: ' + Object.entries(buckets).map(([k, v]) => k + ' → ' + v).join('  '));

const miss = rows.filter((r) => !r.zh).length;
console.log('未翻译: ' + miss + ' / ' + rows.length);
