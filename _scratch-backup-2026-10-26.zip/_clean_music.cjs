/**
 * 清掉台词里的背景音标记。
 *   node _clean_music.cjs <transcript.json>
 *
 * 为什么要有这一步：
 * 这批字幕把背景音标成了 [music]，还用 >> 标说话人切换，两者被错塞进了正文里，
 * 有的甚至整行就只有标记。前 16 集的字幕都没有这些东西，留在里面界面上就是噪点，
 * 也会和第 1~16 集长得不一样。
 *
 * 只动文本，不动行数，除非清理后整行为空（那就连行一起删掉，免得在 UI 上留下空白卡片）。
 */
const fs = require('fs');

const target = process.argv[2];
if (!target) {
  console.error('用法: node _clean_music.cjs <transcript.json>');
  process.exit(1);
}

/** 去掉 [music] 和 >>，把因此留下的多余空格压成一个，并修掉句内的粘连 */
function cleanText(s) {
  return s
    .replace(/\[music\]/gi, '')
    .replace(/>>/g, '')
    .replace(/\s+/g, ' ')
    .replace(/\s+([,.;:!?])/g, '$1')
    .trim();
}

const j = JSON.parse(fs.readFileSync(target, 'utf8'));
const before = j.lines.length;

// 清完如果一个字母数字都不剩，这行就没有内容可言了。
// 除了纯标记行，还有一种：字幕把引语尾巴甩到了下一行，留下一整行孤零零的引号。
const kept = j.lines
  .map(l => ({ ...l, en: cleanText(l.en) }))
  .filter(l => /[0-9A-Za-z]/.test(l.en));

// index 是用来排序和定位的，删行后必须重排，不然会出现 1,2,3,5,6 这种断号
kept.forEach((l, i) => {
  l.index = i + 1;
});

const removed = before - kept.length;
j.lines = kept;
fs.writeFileSync(target, JSON.stringify(j, null, 2) + '\n', 'utf8');

// 顺手报一下还剩哪些可疑符号，方便人工核对有没有漏网
const leftovers = kept.filter(l => /\[|>|♪/.test(l.en));
console.log(`${target}: ${before} → ${kept.length} 行 (移除 ${removed} 行纯标记)`);
if (leftovers.length) {
  console.log(`仍有 ${leftovers.length} 行含可疑符号，请人工核对:`);
  leftovers.forEach(l => console.log(`   #${l.index} ${l.en}`));
}
