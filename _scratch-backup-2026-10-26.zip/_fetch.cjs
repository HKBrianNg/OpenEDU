// 临时：批量抓取 #4-#52 的英文字幕到 _subs/（可分批：node _fetch.cjs 4 15）
const fs = require('fs');
const { execFileSync } = require('child_process');
const PY = 'C:\\Python314\\python.exe';

const d = JSON.parse(fs.readFileSync('public/data/EnglishVideo/Kingdergarten/Kingdergarten.json', 'utf8'));
const from = Number(process.argv[2] || 4);
const to = Number(process.argv[3] || 15);
const items = (d.items || []).filter((i) => i.id >= from && i.id <= to);

fs.mkdirSync('_subs', { recursive: true });
let ok = 0;
const failed = [];

for (const it of items) {
  const m = it.url.match(/[?&]v=([A-Za-z0-9_-]{11})/);
  if (!m) { failed.push(`#${it.id} url 无效`); continue; }
  const vid = m[1];
  const out = `_subs/${vid}.en.json3`;
  if (fs.existsSync(out)) { ok++; console.log(`#${it.id} ${vid} 已存在`); continue; }
  try {
    execFileSync(
      PY,
      ['-m', 'yt_dlp', '--write-sub', '--write-auto-sub', '--skip-download', '--sub-lang', 'en',
       '--sub-format', 'json3', '--extractor-args', 'youtube:player_client=android,web_safari,tv',
       '-o', `_subs/${vid}.%(ext)s`, '--no-warnings', `https://www.youtube.com/watch?v=${vid}`],
      { encoding: 'utf8', timeout: 90000, stdio: 'pipe' },
    );
    if (fs.existsSync(out)) { ok++; console.log(`#${it.id} ${vid} ✓`); }
    else { failed.push(`#${it.id} ${vid} 无字幕`); console.log(`#${it.id} ${vid} 无字幕`); }
  } catch (e) {
    failed.push(`#${it.id} ${vid} 失败`);
    console.log(`#${it.id} ${vid} 失败`);
  }
}
console.log(`\n成功 ${ok} / ${items.length}` + (failed.length ? ` | 失败: ${failed.join(', ')}` : ''));
