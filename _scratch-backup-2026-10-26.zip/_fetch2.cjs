// 临时：为每集定位「官方频道」版本（有手动字幕）并抓字幕，存到 _subs2/
// 视频 URL 保持不变（第三方那个能站内播放），官方版只用于取高质量字幕文本。
const fs = require('fs');
const { execFileSync } = require('child_process');
const PY = 'C:\\Python314\\python.exe';

const d = JSON.parse(fs.readFileSync('public/data/EnglishVideo/Kingdergarten/Kingdergarten.json', 'utf8'));
const from = Number(process.argv[2] || 4);
const to = Number(process.argv[3] || 15);
const items = (d.items || []).filter((i) => i.id >= from && i.id <= to);

fs.mkdirSync('_subs2', { recursive: true });
const secs = (s) => { const p = (s || '0:00').split(':').map(Number); return p.length === 3 ? p[0] * 3600 + p[1] * 60 + p[2] : p[0] * 60 + p[1]; };
const MAP_FILE = '_official_map.json';
const map = fs.existsSync(MAP_FILE) ? JSON.parse(fs.readFileSync(MAP_FILE, 'utf8')) : {};

for (const it of items) {
  const epName = (it.episode || '').split(' - ')[1] || it.englishName.split(': ')[1] || '';
  const key = String(it.id);
  let vid = map[key];

  if (!vid) {
    let raw = '';
    try {
      raw = execFileSync(PY, ['-m', 'yt_dlp', '--no-warnings', '--flat-playlist', '--get-title', '--get-id', '--get-duration',
        `ytsearch8:Peppa Pig ${epName} full episode Cartoons for Children`], { encoding: 'utf8', timeout: 90000 });
    } catch { console.log(`#${it.id} ${epName} 搜索失败`); continue; }
    const lines = raw.split('\n').map((x) => x.trim()).filter(Boolean);
    let best = null;
    for (let i = 0; i + 2 < lines.length; i += 3) {
      const title = lines[i], id = lines[i + 1], dur = lines[i + 2];
      if (!/^[A-Za-z0-9_-]{11}$/.test(id)) continue;
      const s = secs(dur);
      const hit = new RegExp(epName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i').test(title);
      const official = /cartoons for children/i.test(title);
      if (hit && official && s >= 250 && s <= 400) { best = { id, title, dur }; break; }
    }
    if (!best) { console.log(`#${it.id} ${epName} 无官方版候选`); continue; }
    vid = best.id;
    map[key] = vid;
    console.log(`#${it.id} ${epName} → 官方 ${vid} [${best.dur}]`);
  }

  const out = `_subs2/${vid}.en.json3`;
  if (fs.existsSync(out)) { console.log(`#${it.id} 字幕已存在`); continue; }
  try {
    execFileSync(PY, ['-m', 'yt_dlp', '--write-sub', '--write-auto-sub', '--skip-download', '--sub-lang', 'en',
      '--sub-format', 'json3', '--extractor-args', 'youtube:player_client=android,web_safari,tv',
      '-o', `_subs2/${vid}.%(ext)s`, '--no-warnings', `https://www.youtube.com/watch?v=${vid}`],
      { encoding: 'utf8', timeout: 90000, stdio: 'pipe' });
    console.log(fs.existsSync(out) ? `#${it.id} 字幕 ✓` : `#${it.id} 无字幕`);
  } catch { console.log(`#${it.id} 抓字幕失败`); }
}
fs.writeFileSync(MAP_FILE, JSON.stringify(map, null, 2));
