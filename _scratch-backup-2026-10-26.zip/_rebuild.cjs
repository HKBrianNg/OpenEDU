/**
 * YouTube 滚动字幕复原成完整的句子列表。
 *   node _rebuild.cjs <xxx.srv1> <输出.txt>
 *
 * 这个视频的是南没法直接用的：YouTube 自动字幕是「滚动窗口」的，
 * 每个节点只给到流上连续的 1~5 个词，而视频本身每个短语又会念上两三遍。
 * 所以同一句话既被切碎、又被重复。
 *
 * 做法是：先把节点按时间顺序拼回原始语音流，再把流里重复念的部分折叠掉。
 */
const fs = require('fs');

const src = process.argv[2];
const out = process.argv[3];

const raw = fs.readFileSync(src, 'utf8');
const nodes = (raw.match(/<text\b[^>]*>[\s\S]*?<\/text>/g) || []).map(n => {
  const get = k => { const m = n.match(new RegExp(k + '="([^"]*)"')); return m ? m[1] : ''; };
  const text = n.replace(/^<text\b[^>]*>/, '').replace(/<\/text>$/, '').replace(/<[^>]*>/g, '')
    .replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
  return { start: parseFloat(get('start')), text };
});

// [Music] 是视频里短语之间的间隔，正好拿来当切分点
const parts = [];
let buf = [];
for (const n of nodes) {
  if (/^\[.*\]$/.test(n.text)) {
    if (buf.length) parts.push(buf.join(' '));
    buf = [];
    continue;
  }
  buf.push(n.text);
}
if (buf.length) parts.push(buf.join(' '));

console.log(`节点 ${nodes.length} 个 → 音乐间隔切成 ${parts.length} 段`);
console.log('');
console.log('=== 前 14 段原文（未折叠重复）===');
parts.slice(0, 14).forEach((p, i) => console.log(String(i).padStart(3) + '. ' + p));

/**
 * 每个短语这个视频会连着念三遍，把重复折叠掉就还原了。
 *
 * 先贪长：试 8 个词一组的能不能连着重复三次，不行再缩短到 1 个词。
 * 命中之后把后面同样的一并吃掉——有的短语念了不止三遍，
 * 不清理干净会剩下一截卡在下一句的开头。
 */
function removeRepetitions(text) {
  const w = text.split(' ').filter(Boolean);
  // 比对用小写，输出用原始大小写。
  // 自动字幕同一个短语的三遍常常大小写不一致（act your age / Act Your Age / act your age），
  // 按原样严格比对就折不动，整句会散成一堆单词被丢掉。
  const lw = w.map(x => x.toLowerCase());
  const out = [];
  let i = 0;
  while (i < w.length) {
    let hit = null;
    for (let k = Math.min(8, Math.floor((w.length - i) / 3)); k >= 1; k--) {
      const u = lw.slice(i, i + k).join(' ');
      if (lw.slice(i + k, i + 2 * k).join(' ') !== u) continue;
      if (lw.slice(i + 2 * k, i + 3 * k).join(' ') !== u) continue;
      let j = i + 3 * k;
      while (j + k <= w.length && lw.slice(j, j + k).join(' ') === u) j += k;
      hit = { u: w.slice(i, i + k).join(' '), j };
      break;
    }
    if (hit) {
      out.push(hit.u);
      i = hit.j;
    } else {
      out.push(w[i]);
      i += 1;
    }
  }
  return out;
}

// 一段里往往挤着好几十个短语，所以要铺平，不是一段一句
const sentences = parts.flatMap(p => removeRepetitions(p)).map(s => {
  let t = s.trim().replace(/\s+([,.!?])/g, '$1');
  if (!t) return t;
  t = t.charAt(0).toUpperCase() + t.slice(1);
  if (!/[.!?]$/.test(t)) t += '.';
  return t;
}).filter(Boolean);

// 全局去重，保序
const seen = new Set();
const uniq = sentences.filter(s => {
  const k = s.toLowerCase();
  if (seen.has(k)) return false;
  seen.add(k);
  return true;
});

console.log('');
console.log(`=== 折叠后 ${sentences.length} 句 → 去重 ${uniq.length} 句 ===`);
uniq.slice(0, 60).forEach((s, i) => console.log(String(i + 1).padStart(3) + '. ' + s));

if (out) {
  fs.writeFileSync(out, uniq.join('\n') + '\n', 'utf8');
  console.log('');
  console.log('已写入 ' + out);
}
