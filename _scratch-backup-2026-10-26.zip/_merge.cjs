/**
 * 把译文数组写回台词文件。
 *   node _merge.cjs <transcript.json> <zh数组.json>
 * 条数对不上就拒绝写入，避免错行。
 */
const fs = require('fs');

const [target, zhFile] = process.argv.slice(2);
if (!target || !zhFile) {
  console.error('用法: node _merge.cjs <transcript.json> <zh数组.json>');
  process.exit(1);
}

const j = JSON.parse(fs.readFileSync(target, 'utf8'));
const zh = JSON.parse(fs.readFileSync(zhFile, 'utf8'));

if (!Array.isArray(zh)) {
  console.error('译文文件必须是数组');
  process.exit(1);
}
if (zh.length !== j.lines.length) {
  console.error(`条数不符：台词 ${j.lines.length} 行 / 译文 ${zh.length} 条 —— 拒绝写入`);
  process.exit(1);
}

let empty = 0;
j.lines.forEach((l, i) => {
  l.zh = zh[i];
  if (!zh[i]) empty++;
});

if (empty) {
  console.error(`有 ${empty} 条空译文 —— 拒绝写入`);
  process.exit(1);
}

fs.writeFileSync(target, JSON.stringify(j, null, 2) + '\n', 'utf8');
console.log(`${target} 写入 ${j.lines.length} 条译文`);
